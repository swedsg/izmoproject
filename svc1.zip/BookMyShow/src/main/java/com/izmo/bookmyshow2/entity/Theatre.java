package com.izmo.bookmyshow2.entity;



import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Theatre {
@Id
int theatre_id;
@Column(length=20)
String theatre_name;
@Column(length=20)
String city_name;
@Column(length=20)
int ticket_price;
@OneToMany(mappedBy = "theatre",cascade = CascadeType.ALL)
List<Movie_Theatre> mt;





public int getTheatre_id() {
	return theatre_id;
}
public void setTheatre_id(int theatre_id) {
	this.theatre_id = theatre_id;
}

public String getTheatre_name() {
	return theatre_name;
}
public void setTheatre_name(String theatre_name) {
	this.theatre_name = theatre_name;
}
public String getCity_name() {
return city_name;
}
public void setCity_name(String city_name) {
this.city_name = city_name;
}
public int getTicket_price() {
return ticket_price;
}
public void setTicket_price(int ticket_price) {
this.ticket_price = ticket_price;
}




//@Override
//public String toString() {
//	return "Theatre [theatre_id=" + theatre_id + ", theatre_name=" + theatre_name + ", city_name=" + city_name
//			+ ", ticket_price=" + ticket_price + ", mt=" + mt + "]";
//}
public Theatre() {
	super();
	// TODO Auto-generated constructor stub
}
public List<Movie_Theatre> getMt() {
	return mt;
}
public void setMt(List<Movie_Theatre> mt) {
	this.mt = mt;
}
public Theatre(int theatre_id, String theatre_name, String city_name, int ticket_price, List<Movie_Theatre> mt) {
	super();
	this.theatre_id = theatre_id;
	this.theatre_name = theatre_name;
	this.city_name = city_name;
	this.ticket_price = ticket_price;
	this.mt = mt;
}



}