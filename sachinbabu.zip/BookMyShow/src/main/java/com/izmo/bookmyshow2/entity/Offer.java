package com.izmo.bookmyshow2.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Offer {
   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
	int offerid;
	public Offer(int offerid, String offerurl, int percent, String type) {
	//super();
	this.offerid = offerid;
	this.offerurl = offerurl;
	this.percent = percent;
	this.type = type;
}
	public Offer() {
		//super();
		// TODO Auto-generated constructor stub
	}
	public int getOfferid() {
	return offerid;
}
public void setOfferid(int offerid) {
	this.offerid = offerid;
}
public String getOfferurl() {
	return offerurl;
}
public void setOfferurl(String offerurl) {
	this.offerurl = offerurl;
}
public int getPercent() {
	return percent;
}
public void setPercent(int percent) {
	this.percent = percent;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
	String offerurl;
	int percent;
	String type;
	
}
