package com.izmo.bookmyshow2.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Movie_Theatre {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
int id;
@ManyToOne
@JoinColumn(name = "theatre_id")
Theatre theatre;
@ManyToOne
@JoinColumn(name = "movie_id")
Movie movie;

public int getId() {
return id;
}
public void setId(int id) {
this.id = id;
}

public Movie getMovie() {
return movie;
}
public void setMovie(Movie movie) {
this.movie = movie;
}

public Movie_Theatre() {

}
public Movie_Theatre(int id, Theatre theatre, Movie movie) {
// super();
this.id = id;
this.theatre = theatre;
this.movie = movie;
}

public Theatre getTheatre() {
	return theatre;
}
public void setTheatre(Theatre theatre) {
	this.theatre = theatre;
}
//@Override
//public String toString() {
//	return "Movie_Theatre [id=" + id + ", theatre=" + theatre + ", movie=" + movie + "]";
//}



}
