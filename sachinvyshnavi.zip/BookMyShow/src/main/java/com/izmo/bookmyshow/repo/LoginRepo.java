package com.izmo.bookmyshow.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.izmo.bookmyshow.entity.Login;

@Repository
@Transactional
public interface LoginRepo extends JpaRepository<Login, String>
{
@Query("select type from Login l where l.loginid=?1 and l.password=?2")
public String getUserByIdAndPassword(String id,String pwd);

@Modifying
@Query("update Login l set l.password=?1 where l.loginid=?2")
void changePassword(String npass, String loginid);
}
