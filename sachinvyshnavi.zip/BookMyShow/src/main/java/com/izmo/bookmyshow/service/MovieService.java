package com.izmo.bookmyshow.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.bookmyshow.entity.Movie;
import com.izmo.bookmyshow.repo.MovieRepo;



@Service
public class MovieService {
	@Autowired
	MovieRepo repo4;
	public void addMovie(Movie m) {
		repo4.save(m);
	}
	
	public List<Movie> getAllMovie(){
		return repo4.findAll();
	}
	
	public Movie getMovieById(int movie_id) {
		return repo4.getById(movie_id);
	}
	
	public void updataMovie(Movie m) {
		repo4.save(m);
	}
	public void deleteMovie(int movie_id) {
		repo4.deleteById(movie_id);
	}
}

