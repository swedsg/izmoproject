package com.izmo.bookmyshow.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.bookmyshow.entity.Customer;
import com.izmo.bookmyshow.repo.CustomerRepo;
import com.izmo.bookmyshow.repo.LoginRepo;

@Service
public class CustomerService {

	@Autowired
	CustomerRepo customerRepo;
	
	@Autowired
	LoginRepo loginRepo;
	
	public void register(Customer customer) {
		customerRepo.save(customer);
	}
	
	
	public List<Customer> getAll	() {
		List<Customer> list=customerRepo.findAll();
		return list;
		}

		public Customer updateCustomer(int id) {
		return customerRepo.getById(id);
		}

		public Customer getCustomer(String loginid) {
		Customer customer=customerRepo.getCustomerByLoginId(loginid);
		return customer;

		}

		public void updateCust(String id,Customer customer) {
			 customerRepo.deleteById(Integer.parseInt(id));
				customerRepo.save(customer);
		 
		}

		public void deleteCustomer(int id) {
		customerRepo.deleteById(id);

		}


		public void chaangePass(String npass, String loginid) {
		loginRepo.changePassword(npass,loginid);
		}

	
}
