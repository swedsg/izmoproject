package com.izmo.bookmyshow.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.izmo.bookmyshow.entity.Customer;
@Repository
public interface CustomerRepo extends JpaRepository<Customer, Integer> {

	@Query("select c from Customer c where c.login.loginid=:id")
	public Customer getCustomerByLoginId(@Param("id")String id);

}
