package com.izmo.bookmyshow.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.bookmyshow.entity.Movie;
import com.izmo.bookmyshow.entity.Movie_Theatre;
import com.izmo.bookmyshow.entity.Theatre;
import com.izmo.bookmyshow.service.MovieService;
import com.izmo.bookmyshow.service.Movie_theaterService;
import com.izmo.bookmyshow.service.TheaterService;

@Controller
public class MovieController {
	@Autowired
	MovieService serv4;
	@Autowired
	TheaterService serv5;
	@Autowired
	Movie_theaterService serv6;

	@RequestMapping("/gotoMovieAdd")
	public String gotoMovieAddPage(Model m) {
		m.addAttribute("theaterdate", serv5.getAllTheater());
		System.out.println(m);
		return "addmovie";
	}

	@RequestMapping("/Addmovie")
	public String movieAddData(@RequestParam("movie_name") String movie_name,
			@RequestParam("movie_desc") String movie_desc, @RequestParam("release_date") String release_Date1,
			@RequestParam("duration") String duration, @RequestParam("cover_photo_url") String cover_photo_url,
			@RequestParam("trailer_url") String trailer_url, @RequestParam("theatre_id") String[] theater_id) {
		List<Theatre> l1 = new LinkedList<>();
		for (int i = 0; i < theater_id.length; i++) {
			l1.add(serv5.getTheaterById(Integer.parseInt(theater_id[i])));
		}
		Movie m = new Movie();
		m.setMovie_name(movie_name);
		m.setMovie_desc(movie_desc);
		m.setRelease_date(LocalDate.parse(release_Date1, DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		m.setDuration(Integer.parseInt(duration));
		m.setCover_photo_url(cover_photo_url);
		m.setTrailer_url(trailer_url);

		Movie_Theatre mt = new Movie_Theatre();

		List<Movie_Theatre> l3 = new LinkedList<>();
		l3.add(mt);
		m.setMt(l3);
		serv4.addMovie(m);

		for (int i = 0; i < l1.size(); i++) {
			l1.get(i).setMt(l3);
			serv5.addTheater(l1.get(i));
		}

		for (int i = 0; i < l1.size(); i++) {
			Movie_Theatre mt2 = new Movie_Theatre();
			mt2.setMovie(m);
			mt2.setTheatre(l1.get(i));
			serv6.addMovie_theater(mt2);
		}

		return "admincontrollerspage";
	}

	@RequestMapping("/gotoserchbyidmovie")
	public String gotoSerchByid(@RequestParam("movie_id") String movie_id, Model m) {
		m.addAttribute("singlemoviedata", serv4.getMovieById(Integer.parseInt(movie_id)));
		return "dispmoviebyid";

	}

	@RequestMapping("/gotomovieAdminDisplay")
	public String gotoMovieAdminDisplay(Model m) {
		m.addAttribute("moviedata", serv4.getAllMovie());
		return "moviedispadmin";
		// return "updatemovie";

	}

	@RequestMapping("/gotoUpdatePage")
	public String gotoUpdatePage(@RequestParam("movie_id") String movie_id, Model m) {
		m.addAttribute("singlemoviedata", serv4.getMovieById(Integer.parseInt(movie_id)));
		return "updatemovie";

	}

	@RequestMapping("/movieUpdataData")
	public String updateMoveData(@RequestParam("movie_id") String movie_id,
			@RequestParam("movie_name") String movie_name, @RequestParam("movie_desc") String movie_desc,
			@RequestParam("release_date") String release_date, @RequestParam("duration") String duration,
			@RequestParam("cover_photo_url") String cover_photo_url, @RequestParam("trailer_url") String trailer_url,
			Model m2) {
		Movie m = new Movie();
		m.setMovie_id(Integer.parseInt(movie_id));
		m.setMovie_name(movie_name);
		m.setMovie_desc(movie_desc);
		m.setRelease_date(LocalDate.parse(release_date, DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		m.setDuration(Integer.parseInt(duration));
		m.setCover_photo_url(cover_photo_url);
		m.setTrailer_url(trailer_url);
		serv4.updataMovie(m);
		m2.addAttribute("moviedata", serv4.getAllMovie());
		return "admincontrollerspage";
	}

	@RequestMapping("/deletemoviedata")
	public String deleteMovieData(@RequestParam("movie_id") String movie_id, Model m) {
		serv4.deleteMovie(Integer.parseInt(movie_id));
		m.addAttribute("moviedata", serv4.getAllMovie());
		return "moviedispadmin";
	}

	@RequestMapping("/gotohomepage")
	public String gotoHomePage(Model m) {
		m.addAttribute("moviedata", serv4.getAllMovie());
		return "home";
	}

	@RequestMapping("/h2")
	public String gotoheader2() {
		// return "header1";
		return "headermovies";
	}
	@RequestMapping("/getmoviebyid1")
	public String getmoviebyid(@RequestParam("movie_id") String movie_id, Model m) {
		m.addAttribute("moviedata", serv4.getMovieById(Integer.parseInt(movie_id)));
		return "adminsearchbymovie";

	}
	@RequestMapping("/getmoviebyid")
	public String getmoviebyid1() {
		
		return "adminsearchbymovie";

	}
}
