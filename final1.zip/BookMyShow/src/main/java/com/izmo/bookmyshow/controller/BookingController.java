package com.izmo.bookmyshow.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.bookmyshow.entity.Booking;
import com.izmo.bookmyshow.entity.Movie;
import com.izmo.bookmyshow.entity.Movie_Theatre;
import com.izmo.bookmyshow.entity.Theatre;
import com.izmo.bookmyshow.service.BookingService;
import com.izmo.bookmyshow.service.MovieService;
import com.izmo.bookmyshow.service.Movie_theaterService;
import com.izmo.bookmyshow.service.OfferService;
import com.izmo.bookmyshow.service.TheaterService;





@Controller
public class BookingController {
@Autowired
MovieService serv1;

@Autowired
Movie_theaterService serv2;
@Autowired
TheaterService serv3;
@Autowired
BookingService serv4;
@Autowired
OfferService serv5;
@RequestMapping("/bookingpage")
public String gotoBookingpage(@RequestParam("movie_id") String movie_id,Model m,HttpSession s) {
if(s.getAttribute("customer_id")!=null) {
Movie m1=serv1.getMovieById(Integer.parseInt(movie_id));
List<Movie_Theatre> l1=serv2.getAllMovie_Theator();

List<Theatre> l2=new ArrayList<>();
for(int i=0;i<l1.size();i++)
{
if(l1.get(i).getMovie()!=null) {
if(l1.get(i).getMovie().getMovie_id()==m1.getMovie_id())
l2.add(l1.get(i).getTheatre());
}
}
m.addAttribute("moviedata", m1);
m.addAttribute("theaterdata",l2);
return "bookingmoviedetails";
}
else {
return "index";
}
}
@RequestMapping("/finalbookingticket")
public String gotobookingoverviewpage(@RequestParam("movie_id") String movie_id,@RequestParam("theatre_id") String theater_id,Model m ) {
m.addAttribute("moviedata",serv1.getMovieById(Integer.parseInt(movie_id)));
m.addAttribute("theaterdata",serv3.getTheaterById(Integer.parseInt(theater_id)));

return "finalbooking";

}
@RequestMapping("/addbookingdatatodatabase")
public String addBookingData(@ModelAttribute("book") Booking b) {
serv4.addBokking(b);

return "payment";

}
@RequestMapping("/gotobookingdetailspage")
public String gotoBookingDetailsPage(Model m) {
m.addAttribute("bookingdata",serv4.getAllBooking());
return "bookingdetails";
}
@RequestMapping("/gotohistorypage")
public String gotoHistoryPage(HttpSession s,Model m) {
if(s.getAttribute("customer_id")!=null) {
String customer_id=(String) s.getAttribute("customer_id");
// System.out.println(serv4.getAllByCustomerId(customer_id));
m.addAttribute("bookingdata",serv4.getAllByCustomerId(customer_id));
return "bookhistory";
}
else {
return "index";
}


}
@RequestMapping("/gotohistorypage1")
public String gotoHistoryPage1(HttpSession s,Model m) {
if(s.getAttribute("customer_id")!=null) {
String customer_id=(String) s.getAttribute("customer_id");
// System.out.println(serv4.getAllByCustomerId(customer_id));
m.addAttribute("bookingdata",serv4.getAllByCustomerId(customer_id));
return "viewticket";
}
else {
return "index";
}


}
@RequestMapping("/finalbookingticket1")
public String gotobookingoverviewpage3(@RequestParam("movie_id") String movie_id,@RequestParam("theatre_id") String theater_id,@RequestParam("offerid") String offerid,Model m ) {
//System.out.println(movie_id);
//System.out.println(theater_id);
//System.out.println(offerid);

m.addAttribute("moviedata",serv1.getMovieById(Integer.parseInt(movie_id)));
m.addAttribute("theaterdata",serv3.getTheaterById(Integer.parseInt(theater_id)));
m.addAttribute("offerdata", serv5.getoffer(Integer.parseInt(offerid)));
return "finalbooking";

}
@RequestMapping("/changeStatus")
public String addchangestatus(HttpSession s) {
String customer_id=(String) s.getAttribute("customer_id");
String status="success";
serv4.addsatatus(status, customer_id);

return "recipt";

}
@RequestMapping("/deletebookData")
public String deleteticket(@RequestParam("booking_id")String id,HttpSession s, Model m) {
serv4.cncelticket(Integer.parseInt(id));
String customer_id=(String) s.getAttribute("customer_id");
//System.out.println(serv4.getAllByCustomerId(customer_id));
m.addAttribute("bookingdata",serv4.getAllByCustomerId(customer_id));
return "bookhistory";

}
@RequestMapping("/gotobookingbyid")
public String gotobookingbyidPage(@RequestParam("booking_id") String booking_id,Model m) {
	m.addAttribute("bookingdata",serv4.getBookById(Integer.parseInt(booking_id)));
	return "searchbybookingid";
	
}
@RequestMapping("/findbookingbyid")
public String gotobookingsearchbyid() {
	
	return "searchbybookingid";
	
}
@RequestMapping("/deletebookData1")
public String gotobookingsearchbyiddel(@RequestParam("booking_id")String id) {
	serv4.cncelticket(Integer.parseInt(id));
	return "searchbybookingid";
	
}

}
