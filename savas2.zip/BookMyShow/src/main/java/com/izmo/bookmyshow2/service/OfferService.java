package com.izmo.bookmyshow2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.bookmyshow2.entity.Offer;
import com.izmo.bookmyshow2.repo.OfferRepo;
@Service
public class OfferService {
@Autowired
 OfferRepo repo;
public void addoffer(Offer f) {
	repo.save(f);
}
public List<Offer> viewoffer() { 
	  return repo.findAll();
}
public Offer getoffer(int id) { 
	  return repo.getById(id);
}
public void deleteoffer(int id) { 
	 repo.deleteById(id);
}
}
