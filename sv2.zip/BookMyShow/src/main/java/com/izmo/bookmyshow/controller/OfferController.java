package com.izmo.bookmyshow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.bookmyshow.entity.Offer;
import com.izmo.bookmyshow.service.OfferService;

@Controller
public class OfferController {
	@Autowired
	OfferService service;
    @RequestMapping("/gotoaddoffer")
	public String gotoaddoffer() {
		return "addoffer";
	}
    @RequestMapping("/offer1")
    public String saveoffer(@ModelAttribute Offer f) {
       service.addoffer(f);
    	return "admincontrollerspage";
    }
    @RequestMapping("/viewoffer1")
    public String viewoffer(Model m) {
    	m.addAttribute("offerdata", service.viewoffer());
    	return "viewoffer";
    }
    @RequestMapping("/offerup")
    public String updateoffer(@RequestParam("id") String offerid,Model m) {
    	m.addAttribute("offerdata", service.getoffer(Integer.parseInt(offerid)));
    	return "updateoffer";
    }
    @RequestMapping("/offerupdate")
    public String updatofferdata(@ModelAttribute Offer f,Model m) {
       service.addoffer(f);
       m.addAttribute("offerdata", service.viewoffer());
    	return "viewoffer";
    }
    @RequestMapping("/offerDel")
    public String deleteofferdata(@RequestParam ("id") String f,Model m) {
    	service.deleteoffer(Integer.parseInt(f));
       m.addAttribute("offerdata", service.viewoffer());
    	return "viewoffer";
    }
    @RequestMapping("/gotoofferdatabase")
    public String gotoHomePage(Model m,@RequestParam("movie_id") String movieid,@RequestParam("theatre_id") String theatre_id) {
    //System.out.println(movieid);
    //m.addAttribute("data1",id);
    m.addAttribute("data2",Integer.parseInt(movieid));
    m.addAttribute("data3",Integer.parseInt(theatre_id));
    m.addAttribute("offerdata",service.viewoffer());
    return "offer";
    }

  
}
