package com.izmo.bookmyshow.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.bookmyshow.entity.Theatre;
import com.izmo.bookmyshow.repo.TheaterRepo;


@Service
public class TheaterService {
	@Autowired
    TheaterRepo repo5;
	public void addTheater(Theatre t) {
		repo5.save(t);
	}
	public List<Theatre> getAllTheater(){
		return repo5.findAll();
	}
	public Theatre getTheaterById(int theatre_id) {
		return repo5.getById(theatre_id);
	}
	public void updateTheater(Theatre t) {
		repo5.save(t);
	}
	public void deleteTheater(int theatre_id) {
		repo5.deleteById(theatre_id);
	}
}
