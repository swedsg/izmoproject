package com.izmo.bookmyshow.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.bookmyshow.entity.Movie_Theatre;
import com.izmo.bookmyshow.repo.Movie_theaterRepo;



@Service
public class Movie_theaterService {
	@Autowired
	Movie_theaterRepo repo6;
	public void addMovie_theater(Movie_Theatre mt) {
		repo6.save(mt);
	}
	public Movie_Theatre getMovie_theatorbyId(int id) {
		return repo6.getById(id);
	}
    public List<Movie_Theatre> getAllMovie_Theator(){
    	return repo6.findAll();
    }
}
