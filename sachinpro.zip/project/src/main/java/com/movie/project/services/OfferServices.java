package com.movie.project.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.project.entitys.Offer;
import com.movie.project.repositories.Offerrepo;
@Service
public class OfferServices {
    @Autowired
	Offerrepo repo1;
    
    public void addOfferData(Offer f)
    {
    	repo1.save(f);
    }
    
    public List<Offer> getAllOfferData(){
    	return repo1.findAll();
    }
    
    public void offerDelete(int id) {
    	repo1.deleteById(id);
    }
    
    public Offer getOfferByID(int id) {
		return repo1.getById(id);
    	
    }
    public void offerUpdate(Offer f) {
    	repo1.save(f);
    }
    
     
    
}
