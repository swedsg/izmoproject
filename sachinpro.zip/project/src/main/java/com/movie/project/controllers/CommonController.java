package com.movie.project.controllers;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.movie.project.entitys.Customer;
import com.movie.project.entitys.Offer;
import com.movie.project.entitys.User_type;
import com.movie.project.services.CustomerServices;
import com.movie.project.services.User_typeService;

@Controller
public class CommonController {
	@Autowired
	User_typeService serv4;
	@Autowired
	CustomerServices serv5;
	
	@RequestMapping("/gotologinpage")
	public String gotoLoginPage() {
		return "loginPage";
	}
	
	
	@RequestMapping("/login")
	public String gotoProfilePage(@RequestParam("email") String email,@RequestParam("password") String pass,Model m,HttpSession s) {
		List<User_type>l1=serv4.getAllUser_type();
		List<Customer> l2=serv5.getAllCustomer();
		int k=0,index=-1;
		for(int i=0;i<l2.size();i++) {
			if(email.equals(l2.get(i).getEmail())) {
				for(int j=0;j<l1.size();j++) {
					if(pass.equals(l1.get(j).getPassword())&&l2.get(i).getLogin_id().equals(l1.get(j).getLogin_id())) {
						index=i;
						k=1;
					}
				}
			}
		}
		if(k==1) {
		s.setAttribute("customer_id", l2.get(index).getCustomer_id());
		m.addAttribute("customer_data",l2.get(index));
		return "index";
		}
		else {
			return "loginPage";
		}
		
		
	}
	
    @RequestMapping("/updataCustomer")
	public String gotoCustomerUpdataPage(@RequestParam("customerid") String cust_id,Model m) {
    	Customer c=serv5.getCustomerById(Integer.parseInt(cust_id));
    	m.addAttribute("customerdata",c);
    	m.addAttribute("user_type", serv4.getUser_typeById(c.getLogin_id()));
		return "editProfilePage";
	}
    @RequestMapping("/updateprofile")
    public String updateDataofCoustomer(@RequestParam("customer_id") String cust_id,@RequestParam("login_id") String lg_id,@RequestParam("first_name") String fir_name,@RequestParam("last_name") String las_name,@RequestParam("email") String email,@RequestParam("mobile") String mobile,@RequestParam("date_of_birth") String date_of_birth,@RequestParam("usertype") String usertype,@RequestParam("password") String pass) {
    	Customer c=new Customer();
    	User_type u=new User_type();
    	c.setCustomer_id(Integer.parseInt(cust_id));
    	c.setFirst_name(fir_name);
    	c.setLast_name(las_name);
    	c.setEmail(email);
    	c.setMobile(mobile);
    	c.setDate_of_birth(LocalDate.parse(date_of_birth,DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    	c.setLogin_id(lg_id);
    	u.setLogin_id(lg_id);
    	u.setUsertype(usertype);
    	u.setPassword(pass);
    	serv4.updateUser_type(u);
    	serv5.customerAdd(c);
		return "loginPage";
    }
    @RequestMapping("/deleteCustomer")
    public String deleteCustomer_and_user_type(@RequestParam("customerid") String cust_id) {
    	Customer c=serv5.getCustomerById(Integer.parseInt(cust_id));
    	User_type u=serv4.getUser_typeById(c.getLogin_id());
    	serv5.deleteCustomer(c);
    	serv4.deleteUser_type(u);
		return "loginPage";
    }
    @RequestMapping("/gotoprofilepage")
    public String gotoProfilePage(Model m,HttpSession s) {
    	if(s.getAttribute("customer_id")!=null)
    	{
    	m.addAttribute("customer_data",serv5.getCustomerById((int)s.getAttribute("customer_id")));
    	return "profilepage";
    	}
    	else {
    		return "loginPage";
    	}
    }
    
}
