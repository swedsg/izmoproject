package com.movie.project.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.project.entitys.Movie;
import com.movie.project.entitys.Movie_Theator;
import com.movie.project.entitys.Theater;
import com.movie.project.repositories.Movie_theaterRepo;

@Service
public class Movie_theaterService {
	@Autowired
	Movie_theaterRepo repo6;
	public void addMovie_theater(Movie_Theator mt) {
		repo6.save(mt);
	}
	public Movie_Theator getMovie_theatorbyId(int id) {
		return repo6.getById(id);
	}
    public List<Movie_Theator> getAllMovie_Theator(){
    	return repo6.findAll();
    }
}
