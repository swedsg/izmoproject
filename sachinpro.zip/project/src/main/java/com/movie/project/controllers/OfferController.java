package com.movie.project.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.movie.project.entitys.Movie_Theator;
import com.movie.project.entitys.Offer;
import com.movie.project.services.BookingService;
import com.movie.project.services.CustomerServices;
import com.movie.project.services.Movie_theaterService;
import com.movie.project.services.OfferServices;

@Controller
public class OfferController {
	@Autowired
	OfferServices serv1;
	@Autowired
	CustomerServices serv4;
	@Autowired
    Movie_theaterService serv5;
	@RequestMapping("/gotoOffer")
	public String gotoAddOfferPage() {
		return "addoffer";
	}
	@RequestMapping("/offer")
	public String addOffer(@ModelAttribute Offer f)
	{
      
		List<Offer> l1=serv1.getAllOfferData();
		int k=0;
		if(f.getPercentage()!=0||f.getType()!=null) {
		for(int i=0;i<l1.size();i++) {
			if(l1.get(i).getPercentage()==f.getPercentage()&&l1.get(i).getType().equals(f.getType())) {
				k=1;
				break;
			}
		}
		if(k==0) {
			serv1.addOfferData(f);
			return "addoffer";
		}
		else {
			System.out.println("already present");
			return "addoffer";
		}
		}
		else {
			System.out.println("already present");
			return "addoffer";
		}
		
		
		
	}
	
	@RequestMapping("/showOfferAdmin")
	public String showOfferAdminPage(Model m) {
		m.addAttribute("offer", serv1.getAllOfferData());
		return "offerAdminDisplay";
		
	}
	
	
	@RequestMapping("/")
	public String giveOffer()
	{   //Movie_Theator mt=serv5.getMovie_theatorbyId(71);
	   // System.out.println(mt);
	   
		return "index";
	}
	@RequestMapping("/offerDel")
	public String deleteOfferBYID(@RequestParam("id") String id,Model m) {
		serv1.offerDelete(Integer.parseInt(id));
		m.addAttribute("offer", serv1.getAllOfferData());
		return "offerAdminDisplay";
		
	}
	
	@RequestMapping("/offerup")
	public String gotoUpdateOffer(@RequestParam("id") String id,Model m) {
		m.addAttribute("offer1",serv1.getOfferByID(Integer.parseInt(id)));
		return "offerAdminUpdate";
	}
	@RequestMapping("/offerupdate")
    public String updateOfferByID(@ModelAttribute Offer f,Model m) {
    	serv1.offerUpdate(f);
    	m.addAttribute("offer", serv1.getAllOfferData());
		return "offerAdminDisplay";
    }
	
	@RequestMapping("/offerShow")
	public String showOffer(Model m)
	{
		//serv1.offerUpdate(f);
		m.addAttribute("offer2", serv1.getAllOfferData());
		return "showOffers";
		
	}
	
	
}
