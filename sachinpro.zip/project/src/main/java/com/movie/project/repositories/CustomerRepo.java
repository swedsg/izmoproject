package com.movie.project.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movie.project.entitys.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Integer>{

}
