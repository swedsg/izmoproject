package com.movie.project.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.project.entitys.Customer;
import com.movie.project.repositories.CustomerRepo;

@Service
public class CustomerServices {

@Autowired
CustomerRepo repo2;

public void customerAdd(Customer c) {
	repo2.save(c);
}

public List<Customer> getAllCustomer(){
	return repo2.findAll();
}

public Customer getCustomerById(int id) {
	return repo2.getById(id);
}

public void updateCustomer(Customer c) {
	repo2.save(c);
}
public void deleteCustomer(Customer c) {
	repo2.delete(c);
}
}
