package com.movie.project.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.project.entitys.User_type;
import com.movie.project.repositories.User_typeRepo;

@Service
public class User_typeService {
	@Autowired
     User_typeRepo repo3;
     public void addUser_type(User_type u) {
    	 repo3.save(u);
     }
     public List<User_type> getAllUser_type() {
		return repo3.findAll();
     }
     public User_type getUser_typeById(String user_type_id) {
    	 return repo3.getById(user_type_id);
     }
     public void updateUser_type(User_type u) {
    	 repo3.save(u);
     }
     public void deleteUser_type(User_type u) {
    	 repo3.delete(u);
     }
}
