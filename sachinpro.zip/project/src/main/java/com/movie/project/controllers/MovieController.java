package com.movie.project.controllers;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.movie.project.entitys.Movie;
import com.movie.project.entitys.Movie_Theator;
import com.movie.project.entitys.Theater;
import com.movie.project.services.MovieService;
import com.movie.project.services.Movie_theaterService;
import com.movie.project.services.TheaterService;

@Controller
public class MovieController {
	@Autowired
	MovieService serv4;
	@Autowired
    TheaterService serv5;
	@Autowired
	Movie_theaterService serv6;
	@RequestMapping("/gotoMovieAdd")
	public String gotoMovieAddPage(Model m) {
		m.addAttribute("theaterdate", serv5.getAllTheater());
		return "movieAdd";
	}
	@RequestMapping("/movieAdd")
	public String movieAddData(@RequestParam("movie_name") String movie_name,@RequestParam("movie_desc") String movie_desc,@RequestParam("release_date") String release_Date1,@RequestParam("duration") String duration,@RequestParam("cover_photo_url") String cover_photo_url,@RequestParam("trailer_url") String trailer_url,@RequestParam("theater_id") String[] theater_id) {
		List<Theater> l1=new LinkedList<>();
		for(int i=0;i<theater_id.length;i++) {
		l1.add(serv5.getTheaterById(Integer.parseInt(theater_id[i])));
		}
		Movie m=new Movie();
		m.setMovie_name(movie_name);
		m.setMovie_desc(movie_desc);
		m.setRelease_date(LocalDate.parse(release_Date1,DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		m.setDuration(Integer.parseInt(duration));
		m.setCover_photo_url(cover_photo_url);
		m.setTrailer_url(trailer_url);
//		m.setTheater(l1);
//		serv4.addMovie(m);

		Movie_Theator mt=new Movie_Theator();
		
		List<Movie_Theator> l3=new LinkedList<>();
		l3.add(mt);
		m.setMt(l3);
		serv4.addMovie(m);
		
		for(int i=0;i<l1.size();i++) {
			l1.get(i).setMt(l3);
			serv5.addTheater(l1.get(i));
		}
		
		for(int i=0;i<l1.size();i++) {
			Movie_Theator mt2=new Movie_Theator();
			mt2.setMovie(m);
			mt2.setTheator(l1.get(i));
			serv6.addMovie_theater(mt2);
		}
		



		return "index";
	}
	@RequestMapping("/gotomovieAdminDisplay")
	public String gotoMovieAdminDisplay(Model m) {
		m.addAttribute("moviedata", serv4.getAllMovie());
		return "movieDisplayAdmin";
		
	}
	@RequestMapping("/gotoUpdatePage")
	public String gotoUpdatePage(@RequestParam("movie_id") String movie_id,Model m) {
		m.addAttribute("singlemoviedata",serv4.getMovieById(Integer.parseInt(movie_id)));
		return "movieUpdatePage";
		
	}
	@RequestMapping("/movieUpdataData")
	public String updateMoveData(@RequestParam("movie_id") String movie_id,@RequestParam("movie_name") String movie_name,@RequestParam("movie_desc") String movie_desc,@RequestParam("release_date") String release_date,@RequestParam("duration") String duration,@RequestParam("cover_photo_url") String cover_photo_url,@RequestParam("trailer_url") String trailer_url,Model m2) {
		Movie m=new Movie();
		m.setMovie_id(Integer.parseInt(movie_id));
		m.setMovie_name(movie_name);
		m.setMovie_desc(movie_desc);
		m.setRelease_date(LocalDate.parse(release_date, DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		m.setDuration(Integer.parseInt(duration));
		m.setCover_photo_url(cover_photo_url);
		m.setTrailer_url(trailer_url);
		serv4.updataMovie(m);
		m2.addAttribute("moviedata", serv4.getAllMovie());
		return "movieDisplayAdmin";
	}
	@RequestMapping("/deletemoviedata")
	public String deleteMovieData(@RequestParam("movie_id") String movie_id,Model m) {
		serv4.deleteMovie(Integer.parseInt(movie_id));
		m.addAttribute("moviedata", serv4.getAllMovie());
		return "movieDisplayAdmin";
	}
	@RequestMapping("/gotohomepage")
	public String gotoHomePage(Model m) {
		m.addAttribute("moviedata",serv4.getAllMovie());
		return "homepage";
	}
	
}
