package com.movie.project.entitys;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Offer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private int percentage;
    private String type;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPercentage() {
		return percentage;
	}
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public Offer(int id, int percentage, String type) {
	
		this.id = id;
		this.percentage = percentage;
		this.type = type;
	}
	
	public Offer() {
		
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Offer [id=" + id + ", percentage=" + percentage + ", type=" + type + "]";
	}
    
    
}
