package com.movie.project.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movie.project.entitys.User_type;

public interface User_typeRepo extends JpaRepository<User_type, String> {

}
