package com.movie.project.entitys;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User_type {
	@Id
	String login_id;
	String usertype;
	String password;
	public String getLogin_id() {
		return login_id;
	}
	public void setLogin_id(String login_id) {
		this.login_id = login_id;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public User_type(String login_id, String usertype, String password) {
	//	super();
		this.login_id = login_id;
		this.usertype = usertype;
		this.password = password;
	}
	public User_type() {
	//	super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "User_type [login_id=" + login_id + ", usertype=" + usertype + ", password=" + password + "]";
	}
	
}
