package com.movie.project.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.movie.project.entitys.User_type;
import com.movie.project.services.User_typeService;

@Controller
public class User_typeController {
	@Autowired
	User_typeService serv3;
	@RequestMapping("/gotoUser_type")
	public String gotoUser_typePage() {
		return "signuppage";
		
	}
	@RequestMapping("/user_typeadd")
	public String addUser_TypeData(@ModelAttribute User_type u,Model m) {
		m.addAttribute("user_type_id", u.getLogin_id());
		serv3.addUser_type(u);
		return "customerAdd";
	}
	
	
}
