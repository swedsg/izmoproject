package com.movie.project.entitys;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Movie_Theator {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	@ManyToOne
    @JoinColumn(name = "theater_id")
	Theater theator;
	@ManyToOne
    @JoinColumn(name = "movie_id")
	Movie movie;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
//	public Theater getTheator() {
//		return theator;
//	}
//	public void setTheator(Theater theator) {
//		this.theator = theator;
//	}
	public Movie getMovie() {
		return movie;
	}
	public void setMovie(Movie movie) {
		this.movie = movie;
	}
//	public Movie_Theator(int id, Theater theator, Movie movie) {
//		//super();
//		this.id = id;
//		this.theator = theator;
//		this.movie = movie;
//	}
	public Movie_Theator() {
		
	}
	public Movie_Theator(int id, Theater theator, Movie movie) {
	//	super();
		this.id = id;
		this.theator = theator;
		this.movie = movie;
	}
	public Theater getTheator() {
		return theator;
	}
	public void setTheator(Theater theator) {
		this.theator = theator;
	}
	@Override
	public String toString() {
		return "Movie_Theator [id=" + id + ", theator=" + theator + ", movie=" + movie + "]";
	}
	
	
}
