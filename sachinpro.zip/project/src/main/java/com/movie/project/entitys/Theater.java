package com.movie.project.entitys;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Theater {
    @Id
      int theater_id;
     @Column(length=20)
      String theater_name;
     @Column(length=20)
      String city_name;
     @Column(length=20)
      int ticket_price;
     @OneToMany(mappedBy = "theator",cascade = CascadeType.ALL)
     List<Movie_Theator> mt;
//     @ManyToOne
//     Movie_Theator mt; 
     

     
	public int getTheater_id() {
		return theater_id;
	}
	public void setTheater_id(int theater_id) {
		this.theater_id = theater_id;
	}
	public String getTheater_name() {
		return theater_name;
	}
	public void setTheater_name(String theater_name) {
		this.theater_name = theater_name;
	}
	public String getCity_name() {
		return city_name;
	}
	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}
	public int getTicket_price() {
		return ticket_price;
	}
	public void setTicket_price(int ticket_price) {
		this.ticket_price = ticket_price;
	}
	

//	public List<Movie> getMovie() {
//		return movie;
//	}
//	public void setMovie(List<Movie> movie) {
//		this.movie = movie;
//	}
	
//	public Theater(int theater_id, String theater_name, String city_name, int ticket_price, List<Movie> movie) {
//		super();
//		this.theater_id = theater_id;
//		this.theater_name = theater_name;
//		this.city_name = city_name;
//		this.ticket_price = ticket_price;
//		this.movie = movie;
//	}
	public Theater() {
		//super();
		// TODO Auto-generated constructor stub
	}
	public List<Movie_Theator> getMt() {
		return mt;
	}
	public void setMt(List<Movie_Theator> mt) {
		this.mt = mt;
	}
	public Theater(int theater_id, String theater_name, String city_name, int ticket_price, List<Movie_Theator> mt) {
		super();
		this.theater_id = theater_id;
		this.theater_name = theater_name;
		this.city_name = city_name;
		this.ticket_price = ticket_price;
		this.mt = mt;
	}
//	public Movie_Theator getMt() {
//		return mt;
//	}
//	public void setMt(Movie_Theator mt) {
//		this.mt = mt;
//	}
//	public Theater(int theater_id, String theater_name, String city_name, int ticket_price, Movie_Theator mt) {
//		super();
//		this.theater_id = theater_id;
//		this.theater_name = theater_name;
//		this.city_name = city_name;
//		this.ticket_price = ticket_price;
//		this.mt = mt;
//	}
//	@Override
//	public String toString() {
//		return "Theater [theater_id=" + theater_id + ", theater_name=" + theater_name + ", city_name=" + city_name
//				+ ", ticket_price=" + ticket_price + ", mt=" + mt + ", booking=" + booking + "]";
//	}
	@Override
	public String toString() {
		return "Theater [theater_id=" + theater_id + ", theater_name=" + theater_name + ", city_name=" + city_name
				+ ", ticket_price=" + ticket_price + "]";
	}
     
	
     
}
