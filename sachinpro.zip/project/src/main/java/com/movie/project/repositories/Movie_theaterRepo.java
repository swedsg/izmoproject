package com.movie.project.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.movie.project.entitys.Movie;
import com.movie.project.entitys.Movie_Theator;
import com.movie.project.entitys.Theater;

public interface Movie_theaterRepo extends JpaRepository<Movie_Theator, Integer> {
	
}
