package com.movie.project.entitys;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
@Entity
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int booking_id;
	int customer_id;
	int movie_id;
	int theater_id;
	Date booking_date;
	int no_of_seats;

   


	public int getBooking_id() {
		return booking_id;
	}




	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}




	public int getCustomer_id() {
		return customer_id;
	}




	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}




	public int getMovie_id() {
		return movie_id;
	}




	public void setMovie_id(int movie_id) {
		this.movie_id = movie_id;
	}




	public int getTheater_id() {
		return theater_id;
	}




	public void setTheater_id(int theater_id) {
		this.theater_id = theater_id;
	}




	public Date getBooking_date() {
		return booking_date;
	}




	public void setBooking_date(Date booking_date) {
		this.booking_date = booking_date;
	}




	public int getNo_of_seats() {
		return no_of_seats;
	}




	public void setNo_of_seats(int no_of_seats) {
		this.no_of_seats = no_of_seats;
	}




	public Booking(int booking_id, int customer_id, int movie_id, int theater_id, Date booking_date,
			int no_of_seats) {
		super();
		this.booking_id = booking_id;
		this.customer_id = customer_id;
		this.movie_id = movie_id;
		this.theater_id = theater_id;
		this.booking_date = booking_date;
		this.no_of_seats = no_of_seats;
	}




	@Override
	public String toString() {
		return "Booking [booking_id=" + booking_id + ", customer_id=" + customer_id + ", movie_id=" + movie_id
				+ ", theater_id=" + theater_id + ", booking_date=" + booking_date + ", no_of_seats=" + no_of_seats
				+ "]";
	}




	public Booking() {
		//super();
		// TODO Auto-generated constructor stub
	}
	
	
}
