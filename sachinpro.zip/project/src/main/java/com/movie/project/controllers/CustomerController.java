package com.movie.project.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.movie.project.entitys.Customer;
import com.movie.project.services.CustomerServices;

@Controller
public class CustomerController {
	
	@Autowired CustomerServices serv2;
	@RequestMapping("/custadd")
	public String goToCustAddPage() {
		return "customerAdd";
	}
	
	@RequestMapping("/addCustData")
	public String addCustData(@RequestParam("first_name")  String first_name,@RequestParam("last_name")  String last_name, @RequestParam("email")  String email , @RequestParam("mobile")  String mobile, @RequestParam("date_of_birth")  String date_of_birth,@RequestParam("login_id")  String login_id) throws ParseException {
		Customer c=new Customer();
		c.setFirst_name(first_name);
		c.setLast_name(last_name);
		c.setEmail(email);
		c.setMobile(mobile);
		LocalDate date1=LocalDate.parse(date_of_birth,DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		c.setDate_of_birth(date1);
		c.setLogin_id(login_id);
		System.out.println(date1);
		serv2.customerAdd(c);
		return "index";
	}
    @RequestMapping("/logout")
	public String logout(HttpSession s) {
		s.removeAttribute("customer_id");
		return "index";
	}
}
