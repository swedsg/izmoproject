package com.movie.project.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.project.entitys.Theater;
import com.movie.project.repositories.TheaterRepo;

@Service
public class TheaterService {
	@Autowired
    TheaterRepo repo5;
	public void addTheater(Theater t) {
		repo5.save(t);
	}
	public List<Theater> getAllTheater(){
		return repo5.findAll();
	}
	public Theater getTheaterById(int theater_id) {
		return repo5.getById(theater_id);
	}
	public void updateTheater(Theater t) {
		repo5.save(t);
	}
	public void deleteTheater(int theater_id) {
		repo5.deleteById(theater_id);
	}
}
