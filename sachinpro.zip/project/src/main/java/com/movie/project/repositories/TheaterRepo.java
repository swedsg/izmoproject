package com.movie.project.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movie.project.entitys.Theater;

public interface TheaterRepo extends JpaRepository<Theater, Integer>{

}
