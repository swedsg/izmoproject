package com.movie.project.controllers;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.movie.project.entitys.Booking;
import com.movie.project.entitys.Movie;
import com.movie.project.entitys.Movie_Theator;
import com.movie.project.entitys.Theater;
import com.movie.project.services.BookingService;
import com.movie.project.services.MovieService;
import com.movie.project.services.Movie_theaterService;
import com.movie.project.services.TheaterService;

@Controller
public class BokkingController {
	@Autowired
	MovieService serv1;
	
	@Autowired
	Movie_theaterService serv2;
	@Autowired
	TheaterService serv3;
	@Autowired
	BookingService serv4;
	
	@RequestMapping("/gotobokkingpage")
    public String gotoBokkingpage(@RequestParam("movie_id") String mivie_id,Model m,HttpSession s) {
		if(s.getAttribute("customer_id")!=null) {
		Movie m1=serv1.getMovieById(Integer.parseInt(mivie_id));
		List<Movie_Theator> l1=serv2.getAllMovie_Theator();
		System.out.println(l1.size());
		List<Theater> l2=new ArrayList<>();
		for(int i=0;i<l1.size();i++)
		{
			if(l1.get(i).getMovie()!=null) {
			if(l1.get(i).getMovie().getMovie_id()==m1.getMovie_id())
				l2.add(l1.get(i).getTheator());
			}
		}
		m.addAttribute("moviedata", m1);
		m.addAttribute("theaterdata",l2);
    	return "bookingpagewithmovie";
		}
		else {
			return "loginPage";
		}
    }
	@RequestMapping("/gotobookingoverviewpage")
	public String gotobookingoverviewpage(@RequestParam("movie_id") String movie_id,@RequestParam("theater_id") String theater_id,Model m ) {
		m.addAttribute("moviedata",serv1.getMovieById(Integer.parseInt(movie_id)));
		m.addAttribute("theaterdata",serv3.getTheaterById(Integer.parseInt(theater_id)));
//		for(int i=0;i<booking_date.length;i++) {
//			if(booking_date[i]!="")
//			System.out.println(booking_date[i]);
//		}
//		LocalDate show_date=LocalDate.parse(booking_date[0],DateTimeFormatter.ofPattern("yyyy-MM-dd"));
//		m.addAttribute("booking_date",show_date);
//		int n=Integer.parseInt(no_of_seats[0]);
//		m.addAttribute("no_of_seats",n);
//		m.addAttribute("totalamount",n*serv3.getTheaterById(Integer.parseInt(theater_id)).getTicket_price());
		return "bookingoverviewpage";
		
	}
	@RequestMapping("/addbookingdata")
	public String addBookingData(@ModelAttribute Booking b) {
		serv4.addBokking(b);
		return "index";
		
	}
	@RequestMapping("/gotobookingdetailspage")
	public String gotoBookingDetailsPage(Model m) {
		m.addAttribute("bookingdata",serv4.getAllBooking());
		return "bookingdetails";
	}
	@RequestMapping("/gotohistorypage")
	public String gotoHistoryPage(HttpSession s,Model m) {
		if(s.getAttribute("customer_id")!=null) {
			int customer_id=(int) s.getAttribute("customer_id");
//			System.out.println(serv4.getAllByCustomerId(customer_id));
			m.addAttribute("bookingdata",serv4.getAllByCustomerId(customer_id));
			return "historypage";
		}
		else {
			return "loginPage";
		}
		
		
	}
}
