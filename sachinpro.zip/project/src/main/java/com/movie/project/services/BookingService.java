package com.movie.project.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.project.entitys.Booking;
import com.movie.project.repositories.BookingRepo;

@Service
public class BookingService {
	@Autowired
	BookingRepo repo7;
	public void addBokking(Booking b) {
		repo7.save(b);
	}
	public List<Booking> getAllBooking() {
		return repo7.findAll();
	}
	
	public List<Booking> getAllByCustomerId(int customer_id){
		System.out.println(customer_id+"-->");
		return repo7.getbyCustomer(customer_id);
	}
}
