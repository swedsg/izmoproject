package com.dm.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeconddemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
