package com.izmo.bookmyshow.controller;



import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.bookmyshow.entity.Customer;
import com.izmo.bookmyshow.entity.Login;
import com.izmo.bookmyshow.entity.Movie;
import com.izmo.bookmyshow.service.CustomerService;
import com.izmo.bookmyshow.service.LoginService;



@Controller
public class BookMyShowController {

@Autowired
CustomerService cservice;
@Autowired
LoginService cservice1;

@RequestMapping("/")
public String getMessage1()
{
return "home";
}

@RequestMapping("/test")
public String getMessage()
{
return "index";
}
@RequestMapping(value="/login",method = RequestMethod.POST)
public String getLogin(@RequestParam("uname")String id,@RequestParam("pwd")String pwd,Model model,HttpSession session)
{
String type=cservice1.getType(id, pwd);
if(type==null) {
model.addAttribute("msg","invalid credentials!!");
return "index";
}
else if(type.equals("admin"))
{
session.setAttribute("name","admin");
return "admincontrollerspage";
}
else if(type.equals("customer"))
{
session.setAttribute("name","customer");
return "home";
}
else
{
return null;
}
}

@RequestMapping(value="/signup", method = RequestMethod.GET)
public String signup() {
return "signup";
}

@RequestMapping(value="/create", method = RequestMethod.POST)
public String createCustomer(@RequestParam("fname")String fname,
@RequestParam("lname")String lname,
@RequestParam("email")String email,
@RequestParam("mobile")String mobile,
@RequestParam("dob")String dob,
@RequestParam("id")String loginid,
@RequestParam("pwd")String pwd,
Model model)
{
Customer customer=new Customer();
customer.setfName(fname);
customer.setlName(lname);
customer.setEmail(email);
customer.setMobileNo(mobile);
customer.setDob(dob);
Login login=new Login();
login.setLoginid(loginid);
login.setPassword(pwd);
login.setType("customer");
customer.setLogin(login);

cservice.register(customer);

return "index";

}
@RequestMapping("/homepage")
public String gotohomepage() {
	return "home";
}
@RequestMapping("/gotoadmincontroller")
public String gotoadmincontrollerpage() {
	return "admincontrollerspage";
}
@RequestMapping("/gotoaddmovie")
public String gotoaddmovie() {
	return "addmovie";
}
@RequestMapping("/gotoaddtheatre")
public String gotoaddtheatre() {
	return "addtheatre";
}
@RequestMapping("/gotomovieupdate")
public String gotomovieupdate() {
	return "updatemovie";
}
@RequestMapping("/gototheatreupdate")
public String gototheatreupdate() {
	return "updatetheatre";
}
@RequestMapping("/login1")
public String gotologin1() {
	return "index";
}
@RequestMapping("/offer")
public String gotooffer() {
	return "offer";
}

@RequestMapping("/insertmovie")
public String addmovie(@ModelAttribute Movie m)
{
	System.out.println(m);
return "index";
}

}