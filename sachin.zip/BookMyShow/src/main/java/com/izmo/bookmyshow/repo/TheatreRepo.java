package com.izmo.bookmyshow.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.izmo.bookmyshow.entity.Theatre;



public interface TheatreRepo extends JpaRepository<Theatre, Integer> {

}

