package com.izmo.bookmyshow.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.bookmyshow.entity.Movie;
import com.izmo.bookmyshow.repo.MovieRepo;



@Service
public class AdminService {
	@Autowired
	MovieRepo repo;
	public void addMovie(Movie m)
	{
	
	  repo.save(m);
	}
}
