package com.izmo.bookmyshow.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.bookmyshow.entity.Customer;
import com.izmo.bookmyshow.repo.CustomerRepo;

@Service
public class CustomerService {

	@Autowired
	CustomerRepo customerRepo;
	
	public void register(Customer customer) {
		customerRepo.save(customer);
	}

}
