package com.izmo.bookmyshow.entity;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.ManyToMany;

import javax.persistence.Table;

import org.springframework.data.annotation.Id;

@Entity
@Table(name = "theatre")
public class Theatre {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "theatre_id ",length = 20)
	private int theatre_id ;
	@Column(name = "theatre_name",length = 50)
	private String theatre_name;
	@Column(name = "city_name",length = 50)
	private String city_name;
	@Column(name = "ticket_price")
	private double ticket_price;
	@ManyToMany(cascade = CascadeType.ALL,mappedBy ="theatre" )
	private List<Movie> movie=new ArrayList<Movie>();
	public Theatre(int theatre_id, String theatre_name, String city_name, double ticket_price) {
		super();
		
		this.theatre_name = theatre_name;
		this.city_name = city_name;
		this.ticket_price = ticket_price;
	}
	
	public List<Movie> getMovie() {
		return movie;
	}

	public void setMovie(List<Movie> movie) {
		this.movie = movie;
	}

	public Theatre() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getTheatre_id() {
		return theatre_id;
	}
	public void setTheatre_id(int theatre_id) {
		this.theatre_id = theatre_id;
	}
	public String getTheatre_name() {
		return theatre_name;
	}
	public void setTheatre_name(String theatre_name) {
		this.theatre_name = theatre_name;
	}
	public String getCity_name() {
		return city_name;
	}
	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}
	public double getTicket_price() {
		return ticket_price;
	}
	public void setTicket_price(double ticket_price) {
		this.ticket_price = ticket_price;
	}
	
}
