package com.izmo.bookmyshow2.entity;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int payment_id;
	private String customer_id;
	private String movie_name;
	private String theatre_name;
	private int total_price;
	private String status;
	private Date booking_date;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="booking_id")
	private Booking b;
	
	public int getPayment_id() {
		return payment_id;
	}
	public void setPayment_id(int payment_id) {
		this.payment_id = payment_id;
	}
	public Booking getB() {
		return b;
	}
	public void setB(Booking b) {
		this.b = b;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getMovie_name() {
		return movie_name;
	}
	public void setMovie_name(String movie_name) {
		this.movie_name = movie_name;
	}
	public String getTheatre_name() {
		return theatre_name;
	}
	public void setTheatre_name(String theatre_name) {
		this.theatre_name = theatre_name;
	}
	public int getTotal_price() {
		return total_price;
	}
	public void setTotal_price(int total_price) {
		this.total_price = total_price;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getBooking_date() {
		return booking_date;
	}
	public void setBooking_date(Date booking_date) {
		this.booking_date = booking_date;
	}
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Payment(String customer_id, String movie_name, String theatre_name, int total_price, String status,
			Date booking_date) {
		super();
		this.customer_id = customer_id;
		this.movie_name = movie_name;
		this.theatre_name = theatre_name;
		this.total_price = total_price;
		this.status = status;
		this.booking_date = booking_date;
	}
	@Override
	public String toString() {
		return "Payment [customer_id=" + customer_id + ", movie_name=" + movie_name + ", theatre_name=" + theatre_name
				+ ", total_price=" + total_price + ", status=" + status + ", booking_date=" + booking_date + "]";
	}
	
	
	
}
