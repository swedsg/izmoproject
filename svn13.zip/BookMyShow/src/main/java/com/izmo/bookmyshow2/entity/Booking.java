package com.izmo.bookmyshow2.entity;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int booking_id;
	String customer_id;
	int movie_id;
	int theatre_id;
	Date booking_date;
	int no_of_seats;
	
	
	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Booking(int booking_id, String customer_id, int movie_id, int theatre_id, Date booking_date,
			int no_of_seats) {
		super();
		this.booking_id = booking_id;
		this.customer_id = customer_id;
		this.movie_id = movie_id;
		this.theatre_id = theatre_id;
		this.booking_date = booking_date;
		this.no_of_seats = no_of_seats;
	}
	public int getBooking_id() {
		return booking_id;
	}
	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public int getMovie_id() {
		return movie_id;
	}
	public void setMovie_id(int movie_id) {
		this.movie_id = movie_id;
	}
	public int getTheatre_id() {
		return theatre_id;
	}
	public void setTheatre_id(int theatre_id) {
		this.theatre_id = theatre_id;
	}
	public Date getBooking_date() {
		return booking_date;
	}
	public void setBooking_date(Date booking_date) {
		this.booking_date = booking_date;
	}
	public int getNo_of_seats() {
		return no_of_seats;
	}
	public void setNo_of_seats(int no_of_seats) {
		this.no_of_seats = no_of_seats;
	}
	
	
	
}
