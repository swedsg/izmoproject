package com.izmo.bookmyshow2.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.izmo.bookmyshow2.entity.Payment;

public interface PaymentRepo extends JpaRepository<Payment, Integer>{
	@Query("update Payment p set p.status=?1 where p.customer_id=?2")
	void updatestatus(String npass, String loginid);
	}


