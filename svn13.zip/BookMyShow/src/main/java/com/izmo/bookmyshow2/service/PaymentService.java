package com.izmo.bookmyshow2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.bookmyshow2.entity.Payment;
import com.izmo.bookmyshow2.repo.PaymentRepo;

@Service
public class PaymentService {
	@Autowired
	PaymentRepo repo1;
	public void addPayment(Payment p) {
		repo1.save(p);
	}
	
}
