package com.izmo.bookmyshow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.bookmyshow.entity.Customer;
import com.izmo.bookmyshow.entity.Login;
import com.izmo.bookmyshow.service.CustomerService;

@Controller
public class BookMyShowController {
	
	@Autowired
	CustomerService cservice;
	
	@RequestMapping("/test")
	public String getMessage()
	{
		return "index";
	}
	
	@RequestMapping("/login")
	public String getResult(@RequestParam("user")String name,@RequestParam("pwd")String pswd,Model model)
	{
	if(name.equalsIgnoreCase("admin") && pswd.equalsIgnoreCase("pswd"))
	return "admin";
	else if(name.equalsIgnoreCase("customer") && pswd.equalsIgnoreCase("pswd"))
	return "customer";
	else
	{
	model.addAttribute("msg","Invalid Credencials!!!");
	return "index";
	}
	}
	
	@RequestMapping(value="/signup", method = RequestMethod.GET)
	public String signup() {
		return "register";
	}
	
	@RequestMapping(value="/create", method = RequestMethod.POST)
	public String createCustomer(@RequestParam("fname")String fname,
			@RequestParam("lname")String lname,
			@RequestParam("email")String email,
			@RequestParam("mobile")String mobile,
			@RequestParam("dob")String dob,
			@RequestParam("id")String loginid,
			@RequestParam("pwd")String pwd,
			Model model)
	{
		 Customer customer=new Customer();
		 customer.setfName(fname);
		 customer.setlName(lname);
		 customer.setEmail(email);
		 customer.setMobileNo(mobile);
		 customer.setDob(dob);
		 Login login=new Login();
		 login.setLoginid(loginid);
		 login.setPassword(pwd);
		 customer.setLogin(login);
		 
		 cservice.register(customer);
		 
		return "register";
		
	}
	
}
