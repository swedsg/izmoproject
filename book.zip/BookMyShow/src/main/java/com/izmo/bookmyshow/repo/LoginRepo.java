package com.izmo.bookmyshow.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.izmo.bookmyshow.entity.Login;

public interface LoginRepo extends JpaRepository<Login, String>{

}
