package com.izmo.bookmyshow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.izmo.bookmyshow.entity.Movie;
import com.izmo.bookmyshow.entity.Theatre;
import com.izmo.bookmyshow.service.TheaterService;

@Controller
public class TheaterController {
	@Autowired
	TheaterService serv5;
	@RequestMapping("/gotoTheaterAddPage")
     public String gotoAddTheaterPage() {
    	 return "addTheaterAdmin";
     }
	@RequestMapping("/insertTheatre")
	public String addmovie1(@ModelAttribute Movie m)
	{
		return "addtheatre";
	}
	@RequestMapping("/addTheaterDetail")
	public String addTheaterData(@RequestParam("theatre_id") String theater_id,@RequestParam("theatre_name") String theater_name,@RequestParam("city_name") String city_name,@RequestParam("ticket_price") String ticket_price) {
		Theatre t=new Theatre();
		t.setTheatre_id(Integer.parseInt(theater_id));
		t.setTheatre_name(theater_name);
		t.setCity_name(city_name);
		t.setTicket_price(Integer.parseInt(ticket_price));
		serv5.addTheater(t);
		return "admincontrollerspage";
	}
	@RequestMapping("/gotoUpdateTheaterPage")
	public String gotoDisplayTheaterAdminPage(Model m) {
		m.addAttribute("alltheaterdata",serv5.getAllTheater());
		return "displaytheatreadmin";
	}
	@RequestMapping("/gotoupdatetheaterpage")
	public String gotoUpdateTheaterPage(@RequestParam("theatre_id") String theater_id,Model m) {
		m.addAttribute("theaterdate",serv5.getTheaterById(Integer.parseInt(theater_id)));
		return "updatetheatre";
		
	}
	@RequestMapping("/updatetheaterdata")
	public String updateTheaterData(@ModelAttribute Theatre t,Model m) {
		serv5.updateTheater(t);
		m.addAttribute("alltheaterdata",serv5.getAllTheater());
		return "displaytheatreadmin";
	}
	@RequestMapping("/deleteTheaterData")
	public String deleteTheaterData(@RequestParam("theatre_id") String theater_id,Model m) {
		serv5.deleteTheater(Integer.parseInt(theater_id));
		m.addAttribute("alltheaterdata",serv5.getAllTheater());
		return "displaytheatreadmin";
	}
	@RequestMapping("/gototheatrebyid")
	public String gotoTheaterbyidPage(@RequestParam("theatre_id") String theater_id,Model m) {
		m.addAttribute("theatredata",serv5.getTheaterById(Integer.parseInt(theater_id)));
		return "adminsearchbytheatre";
		
	}
	@RequestMapping("/findtheatrebyid")
	public String gotoTheaterbyidPage1() {
		
		return "adminsearchbytheatre";
		
	}
	
}


