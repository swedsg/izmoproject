package com.izmo.bookmyshow.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.izmo.bookmyshow.entity.Offer;

public interface OfferRepo extends JpaRepository<Offer, Integer>{

}
