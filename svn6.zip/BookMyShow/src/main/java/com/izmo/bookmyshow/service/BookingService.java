package com.izmo.bookmyshow.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.bookmyshow.entity.Booking;
import com.izmo.bookmyshow.repo.BookingRepo;


@Service
public class BookingService {
@Autowired
BookingRepo repo;
public void addBokking(Booking b) {
repo.save(b);
}
public List<Booking> getAllBooking() {
return repo.findAll();
}

public List<Booking> getAllByCustomerId(int customer_id){
System.out.println(customer_id+"-->");
return repo.getbyCustomer(customer_id);
}
}
