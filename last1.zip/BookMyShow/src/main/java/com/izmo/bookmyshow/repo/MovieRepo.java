package com.izmo.bookmyshow.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.izmo.bookmyshow.entity.Movie;
@Repository
public interface MovieRepo extends JpaRepository<Movie, Integer>{

	@Query(value = "select * from movie where movie_id IN :names1", nativeQuery = true)
	List<Movie> findUserByNameList1(@Param("names1") List<Integer> names1);
	
	@Query(value="select movie_name from movie  where movie_id=?1",nativeQuery = true)
	public String getbyCustomer5(int id);
}
