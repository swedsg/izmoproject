package com.izmo.bookmyshow.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.izmo.bookmyshow.entity.Customer;
import com.izmo.bookmyshow.entity.Login;
import com.izmo.bookmyshow.repo.LoginRepo;

@Service
public class LoginService {
@Autowired
LoginRepo repo;
public String getType(String id,String pwd)
{
String type=repo.getUserByIdAndPassword(id, pwd);
System.out.println(type);
return type;
}

public Login getLoginbyid(String loginid) {
	Login login=repo.getLoginByLoginId(loginid);
	return login;

	}
}
