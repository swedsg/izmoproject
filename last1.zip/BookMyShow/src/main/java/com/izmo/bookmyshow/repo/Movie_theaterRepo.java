package com.izmo.bookmyshow.repo;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.izmo.bookmyshow.entity.Movie_Theatre;


@Repository
public interface Movie_theaterRepo extends JpaRepository<Movie_Theatre, Integer> {
	
	@Query(value = "select distinct movie_id from movie_theatre  where theatre_id IN :names", nativeQuery = true)
	List<Integer> findUserByNameList(@Param("names") List<Integer> names);
}