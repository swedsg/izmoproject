package com.izmo.bookmyshow.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.izmo.bookmyshow.entity.Theatre;

@Repository
public interface TheaterRepo extends JpaRepository<Theatre, Integer>{

	
	@Query( value="select theatre_id  from theatre t where t.city_name=?1",nativeQuery = true)
	public List<Integer> getUserByIdAndPassword(String city_name);

	@Query(value="select city_name from theatre  where theatre_id=?1",nativeQuery = true)
	public String getbyCustomer6(int id);

}