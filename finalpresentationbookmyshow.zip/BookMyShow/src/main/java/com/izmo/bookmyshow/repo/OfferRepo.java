package com.izmo.bookmyshow.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.izmo.bookmyshow.entity.Offer;
@Repository
public interface OfferRepo extends JpaRepository<Offer, Integer>{
	
	@Query(value="select type from offer  where offerid=?1",nativeQuery = true)
	public String getbyCustomer5(int id);

}
