package com.izmo.bookmyshow.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.izmo.bookmyshow.entity.Booking;
@Repository
@Transactional
public interface BookingRepo extends JpaRepository<Booking,Integer>{
@Query("select b from Booking b where b.customer_id=?1")
public List<Booking> getbyCustomer(String id);

@Query(value="select movie_id from booking  where booking_id=?1",nativeQuery = true)
public String getbyCustomer2(int id);

@Modifying
@Query("update Booking b set b.status=?1 where b.customer_id=?2")
public void changestatus(String status, String customer_id);
}
