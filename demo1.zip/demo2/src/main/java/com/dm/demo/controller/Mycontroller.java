package com.dm.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dm.demo.entity.Course;
import com.dm.demo.entity.Student;
import com.dm.demo.service.CustomerService;

@Controller
public class Mycontroller {
	@Autowired
	CustomerService cservice;
	@RequestMapping("/")
	public String Signup()
	{
		return "signup";
	}
	@RequestMapping("/signup")
	public String Signup1()
	{
		return "signup";
	}
	@RequestMapping(value="/create", method = RequestMethod.POST)
	public String createCust(@RequestParam("sname")String sname,@RequestParam("cname")String cname,@RequestParam("cname1")String cname1)
	{
		Student s=new Student();
		s.setSname(sname);
		Course c=new Course();
		Course c1=new Course();
		c.setCname(cname);
		c1.setCname(cname1);
		s.getStud().add(c);
		s.getStud().add(c1);
		c.getCourse().add(s);
		c1.getCourse().add(s);
		cservice.register(s);
		return "signup";
	}

}
