package com.dm.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
@Entity
@Table(name="course1")
public class Course {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;
	@Column(name="c_name")
private String cname;
	@ManyToMany(cascade = CascadeType.ALL,mappedBy = "stud")
Set<Student> course=new HashSet<>();
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Course(String cname) {
		super();
		this.cname = cname;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public Set<Student> getCourse() {
		return course;
	}
	public void setCourse(Set<Student> course) {
		this.course = course;
	}
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
