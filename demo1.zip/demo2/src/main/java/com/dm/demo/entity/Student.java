package com.dm.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
@Entity
@Table(name="stud1")
public class Student {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;
@Column(name="S_name")
private String sname;
@ManyToMany(cascade = CascadeType.ALL)
@JoinTable(name="stud1_cou",joinColumns = @JoinColumn(name="s_id"),inverseJoinColumns = @JoinColumn(name="c_id"))
Set<Course> stud=new HashSet<>();
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public Set<Course> getStud() {
	return stud;
}
public void setStud(Set<Course> stud) {
	this.stud = stud;
}
public Student() {
	super();
	// TODO Auto-generated constructor stub
}
public Student(String sname) {
	super();
	this.sname = sname;
}
@Override
public String toString() {
	return "Student [id=" + id + ", sname=" + sname + ", stud=" + stud + "]";
}


}
