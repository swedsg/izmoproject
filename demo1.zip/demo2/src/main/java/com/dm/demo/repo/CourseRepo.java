package com.dm.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dm.demo.entity.Course;

public interface CourseRepo extends JpaRepository<Course, Integer> {

}
