package com.dm.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dm.demo.entity.Student;
import com.dm.demo.repo.StudentRepo;

@Service
public class CustomerService {
	@Autowired
StudentRepo studentrepo;
	public void register(Student s)
	{
		studentrepo.save(s);
	}
	
}
