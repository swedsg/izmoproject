package com.izmo.visweswara.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.izmo.visweswara.entity.Trainee;

public interface TraineeRepo extends JpaRepository<Trainee,Integer>{
        
}
