package com.izmo.visweswara;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VisweswaraApplication {

	public static void main(String[] args) {
		SpringApplication.run(VisweswaraApplication.class, args);
	}

}
